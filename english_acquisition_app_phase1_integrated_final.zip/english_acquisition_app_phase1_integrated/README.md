# English Acquisition App

This archive is the cumulative complete Flutter skeleton with the Phase 1 vertical slice integrated into the exact approved folders.

Do not copy the earlier `english_acquisition_phase1_working` files manually. Use this archive as the new baseline.

See:

- `PHASE1_STATUS.md`
- `DEPENDENCY_RULES.md`
- `SKELETON_MANIFEST.md`
