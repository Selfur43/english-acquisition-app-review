import 'package:english_acquisition_app/core/security/secure_session_store.dart';
import 'package:english_acquisition_app/features/authentication/data/repositories/authentication_repository_adapter.dart';
import 'package:english_acquisition_app/features/authentication/data/secure_storage/flutter_credential_store.dart';
import 'package:flutter_test/flutter_test.dart';

final class MemorySecureSessionStore implements SecureSessionStore {
  String? value;

  @override
  Future<void> clear() async => value = null;

  @override
  Future<String?> readUserId() async => value;

  @override
  Future<void> writeUserId(String userId) async => value = userId;
}

void main() {
  test('private user signs in, restores session, and signs out', () async {
    final store = MemorySecureSessionStore();
    final repository = AuthenticationRepositoryAdapter(
      FlutterCredentialStore(store),
    );
    final user = await repository.signIn(
      password: 'change-me-now',
      userName: 'furkan',
    );
    expect(user.id, 'learner-1');
    expect((await repository.restore())?.id, 'learner-1');
    await repository.signOut();
    expect(await repository.restore(), isNull);
  });
}
