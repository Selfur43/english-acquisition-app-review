# Flutter Client Dependency Rules

RULE D-001: app may depend on core, shared and feature public interfaces.
RULE D-002: app owns application composition, routing, theme, localization and startup.
RULE D-003: core may not depend on app or features.
RULE D-004: shared may depend on core only when technically necessary.
RULE D-005: shared may not depend on any feature.
RULE D-006: features may depend on core and shared.
RULE D-007: features may not import another feature's data, domain or presentation internals.
RULE D-008: cross-feature access must use a shared contract, app-level coordinator or backend-owned state.
RULE D-009: presentation may depend on application and presentation-safe domain types.
RULE D-010: presentation may not call local or remote data sources directly.
RULE D-011: application may depend on domain abstractions.
RULE D-012: application may depend on shared kernel identifiers and core-neutral contracts.
RULE D-013: domain may not depend on Flutter widgets, plugins, app, data or presentation.
RULE D-014: data may depend on domain and application abstractions.
RULE D-015: data may depend on core networking, persistence and synchronization.
RULE D-016: data transport models may not escape into presentation.
RULE D-017: repository interfaces belong to the feature that consumes them.
RULE D-018: repository implementations remain in the owning feature's data layer.
RULE D-019: backend-authoritative state must not be recalculated in the client.
RULE D-020: Assessment may produce locally pending responses but not accepted Evidence.
RULE D-021: Evidence is read-only in the client; correction is submitted as a command.
RULE D-022: Readiness is displayed by the client but calculated by the backend.
RULE D-023: Recommendation may propose an action but may not mutate Learning Plan locally.
RULE D-024: Voice may capture and upload recordings but may not declare pronunciation mastery.
RULE D-025: Simulation may retain an interruption checkpoint but may not own authoritative Supplier state.
RULE D-026: offline records must declare local, queued, submitted, accepted, rejected or conflicting status.
RULE D-027: retryable submissions must preserve the same operation identifier.
RULE D-028: one state-management framework shall be used across all features.
RULE D-029: one navigation framework shall be used across the application.
RULE D-030: one local relational persistence system shall own structured offline records.
RULE D-031: credentials must use secure storage and may not use ordinary preferences.
RULE D-032: raw audio must remain in temporary file storage and follow retention rules.
RULE D-033: one user's cached, draft and media data must be scoped by LearnerId.
RULE D-034: feature barrel files may export only the feature's approved public surface.
RULE D-035: empty abstraction layers and pass-through interfaces are prohibited in implementation; placeholders are permitted only in this physical skeleton.
RULE D-036: new shared utilities require at least two real consumers.
RULE D-037: new cross-feature dependencies require an architecture decision record.
RULE D-038: direct AI-provider and voice-provider access from the Flutter client is prohibited.
RULE D-039: provider credentials must never be packaged in the Flutter application.
RULE D-040: all consequential submissions must receive backend acceptance before being shown as finalized.
