# Adr 003 Local Persistence
