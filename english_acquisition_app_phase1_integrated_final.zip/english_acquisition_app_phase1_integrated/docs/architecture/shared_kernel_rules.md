# Shared Kernel Rules
