// Structural placeholder only. No business logic.

enum ConnectivityState { unspecified }
