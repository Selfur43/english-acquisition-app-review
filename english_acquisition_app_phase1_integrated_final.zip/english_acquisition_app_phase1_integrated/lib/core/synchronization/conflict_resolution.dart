// Structural placeholder only. No business logic.

enum ConflictResolution { unspecified }
