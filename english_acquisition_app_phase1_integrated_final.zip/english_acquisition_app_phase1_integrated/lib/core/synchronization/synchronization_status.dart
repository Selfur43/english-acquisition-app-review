// Structural placeholder only. No business logic.

enum SynchronizationStatus { unspecified }
