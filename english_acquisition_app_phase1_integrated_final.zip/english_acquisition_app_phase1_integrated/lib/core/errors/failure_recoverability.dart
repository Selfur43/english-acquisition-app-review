// Structural placeholder only. No business logic.

enum FailureRecoverability { unspecified }
