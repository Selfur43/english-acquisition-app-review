// Structural placeholder only. No business logic.

enum FailureCategory { unspecified }
