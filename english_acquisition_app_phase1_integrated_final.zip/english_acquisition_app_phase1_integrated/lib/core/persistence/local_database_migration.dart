// Structural placeholder only. No business logic.

abstract class LocalDatabaseMigration {}
