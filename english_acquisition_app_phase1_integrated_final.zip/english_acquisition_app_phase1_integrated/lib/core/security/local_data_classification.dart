// Structural placeholder only. No business logic.

enum LocalDataClassification { unspecified }
