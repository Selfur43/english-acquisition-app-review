// Structural placeholder only. No business logic.

class DiagnosticEvent {}
