// Structural placeholder only. No business logic.

enum SupportCondition { unspecified }
