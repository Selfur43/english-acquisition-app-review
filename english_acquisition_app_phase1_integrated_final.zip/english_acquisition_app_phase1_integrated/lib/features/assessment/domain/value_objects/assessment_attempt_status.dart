// Structural placeholder only. No business logic.

enum AssessmentAttemptStatus { unspecified }
