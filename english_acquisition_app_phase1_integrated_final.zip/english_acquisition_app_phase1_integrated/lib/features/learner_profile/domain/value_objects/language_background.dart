// Structural placeholder only. No business logic.

enum LanguageBackground { unspecified }
