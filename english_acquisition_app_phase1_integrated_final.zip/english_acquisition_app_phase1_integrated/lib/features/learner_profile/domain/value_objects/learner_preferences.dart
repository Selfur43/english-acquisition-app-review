// Structural placeholder only. No business logic.

enum LearnerPreferences { unspecified }
