// Structural placeholder only. No business logic.

enum OccupationalBackground { unspecified }
