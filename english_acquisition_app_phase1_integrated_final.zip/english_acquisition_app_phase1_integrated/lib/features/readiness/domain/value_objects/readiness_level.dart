// Structural placeholder only. No business logic.

enum ReadinessLevel { unspecified }
