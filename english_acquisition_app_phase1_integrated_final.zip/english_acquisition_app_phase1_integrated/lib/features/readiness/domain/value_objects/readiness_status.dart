// Structural placeholder only. No business logic.

enum ReadinessStatus { unspecified }
