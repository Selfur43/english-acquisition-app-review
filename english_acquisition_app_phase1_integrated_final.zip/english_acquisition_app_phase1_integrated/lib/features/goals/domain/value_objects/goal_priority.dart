// Structural placeholder only. No business logic.

enum GoalPriority { unspecified }
