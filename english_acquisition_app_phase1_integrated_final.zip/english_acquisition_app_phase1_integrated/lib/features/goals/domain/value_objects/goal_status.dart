// Structural placeholder only. No business logic.

enum GoalStatus { unspecified }
