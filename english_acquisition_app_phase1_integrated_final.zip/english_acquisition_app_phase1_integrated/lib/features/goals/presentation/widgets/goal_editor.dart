// Structural placeholder only. No business logic.

class GoalEditor {}
