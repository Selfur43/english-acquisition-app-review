import 'package:flutter/foundation.dart';

import 'authenticated_user.dart';

@immutable
final class AuthenticationSession {
  const AuthenticationSession({required this.user});

  final AuthenticatedUser user;
}
