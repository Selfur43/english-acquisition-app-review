enum AuthenticationStatus { initializing, authenticated, unauthenticated }
