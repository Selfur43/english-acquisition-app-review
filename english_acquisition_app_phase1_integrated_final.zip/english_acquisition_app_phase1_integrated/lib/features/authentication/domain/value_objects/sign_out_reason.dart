enum SignOutReason { userRequested, sessionExpired, accountDisabled }
