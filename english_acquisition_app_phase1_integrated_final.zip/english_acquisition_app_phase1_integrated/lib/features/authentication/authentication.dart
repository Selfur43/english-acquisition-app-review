import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../core/security/secure_session_store.dart';
import 'application/controllers/authentication_controller.dart';
import 'data/repositories/authentication_repository_adapter.dart';
import 'data/secure_storage/flutter_credential_store.dart';
import 'domain/repositories/authentication_repository.dart';

export 'application/controllers/authentication_controller.dart';
export 'domain/entities/authenticated_user.dart';
export 'domain/value_objects/authentication_status.dart';

final secureSessionStoreProvider = Provider<SecureSessionStore>(
  (ref) => const FlutterSecureSessionStore(FlutterSecureStorage()),
);

final authenticationRepositoryProvider = Provider<AuthenticationRepository>(
  (ref) => AuthenticationRepositoryAdapter(
    FlutterCredentialStore(ref.watch(secureSessionStoreProvider)),
  ),
);

final authenticationControllerProvider =
    ChangeNotifierProvider<AuthenticationController>((ref) {
  final controller = AuthenticationController(
    ref.watch(authenticationRepositoryProvider),
  );
  controller.initialize();
  return controller;
});
