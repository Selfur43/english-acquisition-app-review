import 'package:flutter/foundation.dart';

import '../../data/repositories/authentication_repository_adapter.dart';
import '../../domain/entities/authenticated_user.dart';
import '../../domain/repositories/authentication_repository.dart';
import '../../domain/value_objects/authentication_status.dart';

final class AuthenticationController extends ChangeNotifier {
  AuthenticationController(this._repository);

  final AuthenticationRepository _repository;

  String? errorMessage;
  bool isBusy = false;
  AuthenticationStatus status = AuthenticationStatus.initializing;
  AuthenticatedUser? user;

  Future<void> initialize() async {
    user = await _repository.restore();
    status = user == null
        ? AuthenticationStatus.unauthenticated
        : AuthenticationStatus.authenticated;
    notifyListeners();
  }

  Future<void> signIn({
    required String password,
    required String userName,
  }) async {
    errorMessage = null;
    isBusy = true;
    notifyListeners();
    try {
      user = await _repository.signIn(
        password: password,
        userName: userName,
      );
      status = AuthenticationStatus.authenticated;
    } on AuthenticationFailure catch (failure) {
      errorMessage = failure.message;
      status = AuthenticationStatus.unauthenticated;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<void> signOut() async {
    await _repository.signOut();
    errorMessage = null;
    status = AuthenticationStatus.unauthenticated;
    user = null;
    notifyListeners();
  }
}
