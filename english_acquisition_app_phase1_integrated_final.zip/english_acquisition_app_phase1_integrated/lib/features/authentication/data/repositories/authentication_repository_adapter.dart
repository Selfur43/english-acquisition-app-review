import '../../domain/entities/authenticated_user.dart';
import '../../domain/repositories/authentication_repository.dart';
import '../secure_storage/credential_store.dart';

final class AuthenticationFailure implements Exception {
  const AuthenticationFailure(this.message);

  final String message;
}

final class AuthenticationRepositoryAdapter
    implements AuthenticationRepository {
  const AuthenticationRepositoryAdapter(this._credentialStore);

  final CredentialStore _credentialStore;

  static const _users = <String, AuthenticatedUser>{
    'furkan': AuthenticatedUser(displayName: 'Furkan', id: 'learner-1'),
    'learner2': AuthenticatedUser(displayName: 'Learner 2', id: 'learner-2'),
  };

  @override
  Future<AuthenticatedUser?> restore() async {
    final userId = await _credentialStore.readUserId();
    for (final user in _users.values) {
      if (user.id == userId) return user;
    }
    return null;
  }

  @override
  Future<AuthenticatedUser> signIn({
    required String password,
    required String userName,
  }) async {
    final user = _users[userName.trim().toLowerCase()];
    if (user == null || password != 'change-me-now') {
      throw const AuthenticationFailure('Invalid credentials.');
    }
    await _credentialStore.writeUserId(user.id);
    return user;
  }

  @override
  Future<void> signOut() => _credentialStore.clear();
}
