abstract interface class CredentialStore {
  Future<void> clear();
  Future<String?> readUserId();
  Future<void> writeUserId(String userId);
}
