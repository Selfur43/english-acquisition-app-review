import '../../../../core/security/secure_session_store.dart';
import 'credential_store.dart';

final class FlutterCredentialStore implements CredentialStore {
  const FlutterCredentialStore(this._store);

  final SecureSessionStore _store;

  @override
  Future<void> clear() => _store.clear();

  @override
  Future<String?> readUserId() => _store.readUserId();

  @override
  Future<void> writeUserId(String userId) => _store.writeUserId(userId);
}
