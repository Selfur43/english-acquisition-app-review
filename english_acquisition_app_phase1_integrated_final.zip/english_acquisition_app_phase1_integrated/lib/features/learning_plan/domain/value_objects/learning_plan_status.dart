// Structural placeholder only. No business logic.

enum LearningPlanStatus { unspecified }
