// Structural placeholder only. No business logic.

enum PlanItemStatus { unspecified }
