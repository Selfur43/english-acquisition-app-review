// Structural placeholder only. No business logic.

enum ActivityType { unspecified }
