// Structural placeholder only. No business logic.

class LearningPlanRoutes {}
