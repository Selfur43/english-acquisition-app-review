// Structural placeholder only. No business logic.

enum RecommendationConfidence { unspecified }
