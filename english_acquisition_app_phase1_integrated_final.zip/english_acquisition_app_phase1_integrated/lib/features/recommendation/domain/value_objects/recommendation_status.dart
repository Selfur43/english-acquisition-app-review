// Structural placeholder only. No business logic.

enum RecommendationStatus { unspecified }
