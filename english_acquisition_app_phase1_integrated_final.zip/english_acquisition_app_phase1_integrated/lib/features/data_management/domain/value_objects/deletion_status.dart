// Structural placeholder only. No business logic.

enum DeletionStatus { unspecified }
