// Structural placeholder only. No business logic.

class DataExportRequestModel {}
