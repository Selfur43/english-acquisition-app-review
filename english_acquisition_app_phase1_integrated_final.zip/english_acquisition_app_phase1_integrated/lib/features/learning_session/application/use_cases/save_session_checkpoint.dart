// Structural placeholder only. No business logic.

class SaveSessionCheckpoint {}
