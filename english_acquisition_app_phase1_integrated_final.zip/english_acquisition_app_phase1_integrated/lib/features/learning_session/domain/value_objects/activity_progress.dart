// Structural placeholder only. No business logic.

enum ActivityProgress { unspecified }
