// Structural placeholder only. No business logic.

enum EvidenceStatus { unspecified }
