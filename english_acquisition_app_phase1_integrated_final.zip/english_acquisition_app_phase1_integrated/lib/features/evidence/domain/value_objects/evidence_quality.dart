// Structural placeholder only. No business logic.

enum EvidenceQuality { unspecified }
