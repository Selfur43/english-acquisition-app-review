// Structural placeholder only. No business logic.

enum FeedbackStatus { unspecified }
