// Structural placeholder only. No business logic.

enum FeedbackPriority { unspecified }
