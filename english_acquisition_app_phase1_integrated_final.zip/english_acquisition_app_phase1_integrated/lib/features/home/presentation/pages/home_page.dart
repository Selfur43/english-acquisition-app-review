import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../authentication/authentication.dart';

final class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authentication = ref.watch(authenticationControllerProvider);
    final user = authentication.user;
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () =>
                ref.read(authenticationControllerProvider).signOut(),
            tooltip: 'Sign out',
          ),
        ],
        title: const Text('Today'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(
            'Welcome, ${user?.displayName ?? 'Learner'}',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Text(
                'Phase 1 is active. Secure session restoration, routing, '
                'private sign-in, and the learner home shell are ready.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
