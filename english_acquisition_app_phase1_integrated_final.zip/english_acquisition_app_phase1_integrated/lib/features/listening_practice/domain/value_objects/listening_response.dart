// Structural placeholder only. No business logic.

enum ListeningResponse { unspecified }
