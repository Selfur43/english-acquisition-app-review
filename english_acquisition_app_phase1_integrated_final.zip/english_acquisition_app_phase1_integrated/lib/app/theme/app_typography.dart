// Structural placeholder only. No business logic.

class AppTypography {}
