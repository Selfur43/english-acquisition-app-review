// Structural placeholder only. No business logic.

enum AppEnvironment { unspecified }
