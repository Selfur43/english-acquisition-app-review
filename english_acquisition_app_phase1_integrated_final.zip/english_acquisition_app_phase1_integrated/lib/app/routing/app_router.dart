import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/authentication/authentication.dart';
import '../../features/authentication/domain/value_objects/authentication_status.dart';
import '../../features/authentication/presentation/pages/sign_in_page.dart';
import '../../features/home/presentation/pages/home_page.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  final authentication = ref.watch(authenticationControllerProvider);
  return GoRouter(
    initialLocation: '/home',
    refreshListenable: authentication,
    redirect: (context, state) {
      if (authentication.status == AuthenticationStatus.initializing) {
        return state.matchedLocation == '/starting' ? null : '/starting';
      }
      final isSigningIn = state.matchedLocation == '/sign-in';
      if (authentication.status == AuthenticationStatus.unauthenticated) {
        return isSigningIn ? null : '/sign-in';
      }
      if (isSigningIn || state.matchedLocation == '/starting') return '/home';
      return null;
    },
    routes: [
      GoRoute(
        path: '/starting',
        builder: (context, state) => const Scaffold(
          body: Center(child: CircularProgressIndicator()),
        ),
      ),
      GoRoute(
        path: '/sign-in',
        builder: (context, state) => const SignInPage(),
      ),
      GoRoute(
        path: '/home',
        builder: (context, state) => const HomePage(),
      ),
    ],
  );
});
