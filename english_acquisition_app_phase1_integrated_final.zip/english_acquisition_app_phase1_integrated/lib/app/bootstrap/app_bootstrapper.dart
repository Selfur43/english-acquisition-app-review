// Structural placeholder only. No business logic.

abstract class AppBootstrapper {}
class DefaultAppBootstrapper {}
