// Structural placeholder only. No business logic.

abstract class AppInitializer {}
class DefaultAppInitializer {}
